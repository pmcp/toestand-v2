intro: |
  <p>Op regelmatige basis worden we door verschillende organisaties uitgenodigd om onze werking te duiden en onze kennis te delen. Zo gaven reeds we een voorstelling op Mindblowers, de opening van het academiejaar van de V.U.B. en ‘Human Artistic Festival’ in de Beursschouwburg.
  </p>
  <p>Ook worden we uit allerhande hoeken gecontacteerd met specifieke vragen omtrent tijdelijk ruimtegebruik. Onder meer de gemeente Anderlecht, de Stad Brussel en de Vlaamse Bouwmeester deden al beroep op onze kennis.
  </p>
  <p>Daarnaast geven we ook praktische workshops over tijdelijk ruimtegebruik. Dit niet alleen in België, maar ook over de landsgrenzen heen. Zo gaven we een workshop in Poznan in Polen.
  </p>
  
title: 'Leren van Toestand'
date: '2020-06-09'
template: detail
hide_from_nav: false
fieldset: page__article
id: 9711e65e-c0ce-40db-ba1f-006d3dfc8585
