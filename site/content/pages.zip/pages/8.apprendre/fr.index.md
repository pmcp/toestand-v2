intro: |
  <p>Nous sommes régulièrement invités par diverses organisations à présenter notre travail et fonctionnement et à partager notre savoir-faire. Nous avons donné une présentation à Mindblowers, à l'ouverture de l'année académique de la V.U.B. et au "Human Artistic Festival" au Beursschouwburg.
  </p>
  <p>Nous recevons beaucoup de questions spécifiques sur l'usage temporaire. La commune d'Anderlecht, la Ville de Bruxelles et le Vlaamse Bouwmeester, entre autres, ont déjà fait appel à nos connaissances.
  </p>
  <p>Nous organisons également des ateliers pratiques. Ceci non seulement en Belgique, mais aussi à l'étranger. Par exemple, nous avons donné un atelier à Poznan en Pologne.
  </p>
title: 'Apprendre de Toestand'
id: 9711e65e-c0ce-40db-ba1f-006d3dfc8585
slug: apprendre
