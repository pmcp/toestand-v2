article-header__image:
  - /assets/small-1678361109.jpg
intro: |
  <p><strong></strong><strong>Toestand zoekt een logistieke kracht voor een vervangingscontract begin april - midden augustus</strong>
  </p>
  <p><em>Om ons logistiek team te versterken zoeken we (m/v/x) </em><em>een vlotte knutselaar, propere bricoleur, creatieve bouwer, snelle bijspringer, improviserende teamgenoot; iemand die het potentieel in de dingen ziet; altijd present en bereid om af en toe participatief te werken. Elektriciteitsskills en - ervaring zijn van primordiaal belang en de elektrische motor van een garagepoort wekt je interesse op.</em>
  </p>
  <p><em>Toestand bouwt leegstaande en verlaten ruimtes om tot tijdelijke sociaal-culturele centra. Zo stellen we 'verloren' ruimte beschikbaar voor kleine initiatieven met bijzondere plannen, ongeacht hun kapitaal. Leegstaande loodsen worden levendige plekken waar uiteenlopende sociale, artistieke en sportieve activiteiten plaatsvinden, plekken waar iedereen welkom is, waar ontmoeting, persoonlijke beleving en groei centraal staan.</em>
  </p>
  <p><br><br>
  </p>
  <p><strong>Wat doet een logistieke medewerker bij Toestand?</strong>
  </p>
  <p>- Je vervangt iemand in het logistiek team van Toestand vzw, er zijn al twee fijne mensen in dat team
  </p>
  <p>- Je maakt pas betrokken gebouwen snel functioneel door elektriciteit en water onder handen te nemen.
  </p>
  <p>- Je herstelt uiteenlopende defecten gaande van lekkende boilers, knellende sloten, schakelaars die moeten worden verplaatst, etc.
  </p>
  <p>- Je bouwt podia, tafels, trappen, speeltuigen, kachels, etc
  </p>
  <p>- Je werkt voortdurend aan logische stockage voor zowel werkmateriaal als recupmaterialen bent niet te beroerd om regelmatig spullen te verplaatsen
  </p>
  <p>- Je waakt erover dat de ruimtes ordelijk blijven door signalisatie uit te werken die collega’s en gebruikers begrijpen.
  </p>
  <p>- Je volgt het beheer van deze ruimtes en netheid ervan ook op, daarbij ruim je al eens de rommel van een ander op.
  </p>
  <p>- Je gaat af en toe met partners en vrijwilligers aan de slag of bent bereid hen iets uit te leggen.
  </p>
  <p>- Wanneer er werven aan de gang zijn door professionals of partners volg je deze op.
  </p>
  <p>- Wanneer grote aankopen moeten gebeuren, onderzoek je de prijs-kwaliteitsverhouding.
  </p>
  <p><br>
  </p>
  <p><strong>Wat voor iemand zoeken we?</strong>
  </p>
  <p>- Je bent niet vies van fysiek werk maar kan ook een dag vergaderen.  <br>
  </p>
  <p>- Je hebt ervaring in verschillende domeinen van klusjes: elektriciteit, water, ruwbouw. (opleidingen, werk, stage, opdracht; dat hoeft niet ‘professioneel te zijn’)
  </p>
  <p>- Je herkent defecten of risicovolle situaties en kan probleemoplossend denken.
  </p>
  <p>- Je bent leergierig, zelfredzaam en wil nieuwe uitdagingen aangaan.
  </p>
  <p>- Je kan jezelf goed verplaatsen in de noden van een ander en kan hierdoor correcte
  </p>
  <p>antwoorden bieden op zijn/haar logistieke vragen.
  </p>
  <p>- Je hebt geduld met mensen; je kan op een aangename manier kennis overbrengen. Soms is je grootste doel iemand aan zelfzekerheid te laten winnen, het gebouwde resultaat is minder van belang. Je ziet er niet tegenop dat dan ook achteraf in de container te kieperen.
  </p>
  <p>- Je hebt een rijbewijs B en kan met een bestelwagen rijden.
  </p>
  <p>- Bij het halen van een deadline deins je niet terug voor avond- of weekendwerk.
  </p>
  <p>- Je organiseert zelf je werk en kan goed samenwerken met collega’s rond inhoud en vorm.
  </p>
  <p>- Je spreekt minstens vlot Frans en liefst ook Nederlands en Engels.
  </p>
  <p><strong><br></strong><strong>Wat krijg je daarvoor in ruil?</strong><br>
  </p>
  <p>Toestand biedt je een ⅘ de contract van onbepaalde duur aan voor de functie logistiek medewerker met volgende voorwaarden:
  </p>
  <p>- Werkplek: Brussel
  </p>
  <p>- Regime: voltijdse of deeltijdse tewerkstelling (30,4u) - flexibele uurregeling
  </p>
  <p>- Arbeidsovereenkomst voor bepaalde duur, vervangingscontract ouderschapsverlof
  </p>
  <p>- Loonschaal B1c volgens PC 329.01
  </p>
  <p>- Maaltijdcheques
  </p>
  <p>- Vergoeding woonwerkverkeer
  </p>
  <p>- Eindejaarspremie
  </p>
  <p>- Leuke collega's
  </p>
  <p>- Het gevoel dat je meebouwt aan en beslist over dingen.
  </p>
  <p>Hoe word je logistiek medewerker van Toestand?
  </p>
  <p>Toon iets van je ervaring als logistiek medewerker en vertel ons waarom je graag bij Toestand wil werken in een mail naar jobs<a href="mailto:bie@toestand.be">@toestand.be</a> voor 25 maart.  Gesprekken op dindsdagmorgen de 28ste.
  </p>
title: jobs
date: '2020-02-06'
template: detail
hide_from_nav: false
fieldset: page__article
id: 80f5d364-45b6-4169-960b-669bb6faa8f8
