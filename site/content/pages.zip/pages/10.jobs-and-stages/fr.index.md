intro: |
  <p><strong></strong><strong>Toestand recherche un logisticien pour un contrat de remplacement d'avril à mi-août.</strong>
  </p>
  <p>Pour rejoindre notre équipe logistique, nous recherchons (m/f/x) un.e bricoleur.euse habile, un.e bricoleur.euse propre, un.e constructeur.ice créatif.ve, un.e bricoleur.euse rapide, un.e coéquipier.ère improvisateur.ice ; quelqu'un.e qui voit le potentiel dans les choses ; toujours présent.e et prêt.e à travailler de manière participative de temps en temps. Les compétences et l'expérience en électricité sont primordiales.
  </p>
  <p>Toestand transforme les espaces vacants et abandonnés en centres socioculturels temporaires. Nous mettons ainsi des espaces "perdus" à la disposition de petites initiatives ayant des projets particuliers, quelle que soit leur moyen. Les hangars vides deviennent des lieux vivants où se déroulent diverses activités sociales, artistiques et sportives, des lieux où tout le monde est la.le bienvenu.e, où la rencontre, l'expérience personnelle et l'épanouissement sont au centre des préoccupations.
  </p>
  <p><br><strong>Que fait un assistant logistique chez Toestand ?</strong><br>
  </p>
  <p>- Tu remplaces quelqu'un dans l'équipe logistique de l'asbl Toestand, qui compte déjà deux personnes de qualité.
  </p>
  <p>- Tu rends les nouveaux bâtiments rapidement fonctionnels et t'occupe de l'électricité et de l'eau.
  </p>
  <p>- Tu répares les défauts les plus divers : chaudières qui fuient, serrures qui se coincent, interrupteurs qui doivent être déplacés, etc.
  </p>
  <p>- Tu construis des scènes, des tables, des escaliers, des équipements de jeu, des cuisinières, etc.
  </p>
  <p>- Tu travailles constamment sur le rangement logique du matériel de travail et de récupération et tu n'as pas peur de déplacer les choses régulièrement.
  </p>
  <p>- Tu veilles à ce que les salles restent ordonnées en élaborant une signalisation que les collègues et les utilisateurs comprennent.
  </p>
  <p>- Tu surveilles la gestion et la propreté de ces espaces, nettoyant de temps à autre le désordre d'autrui.
  </p>
  <p>- Tu t'engages parfois avec des partenaires et des bénévoles ou tu es prêt à leur expliquer le fonctionnement de certaines choses.
  </p>
  <p>- Tu fais le suivi des travaux en cours réalisés par les professionnels ou les partenaires.
  </p>
  <p>- Lorsque des achats importants doivent être effectués, tu cherches à obtenir le meilleur rapport qualité-prix.
  </p>
  <p><br><strong>Quel type de personne recherchons-nous ?<br></strong>
  </p>
  <p>- Tu n'es pas réfractaire au travail physique, mais tu peux aussi gérer une journée de réunions.
  </p>
  <p>- Tu as de l'expérience dans différents domaines : électricité, eau, gros œuvre. (formation, travail, stage, mission ; il ne s'agit pas nécessairement d'une expérience professionnelle)
  </p>
  <p>- Tu reconnais les défauts ou les situations à risque et tu peux penser à résoudre les problèmes.
  </p>
  <p>- Tu as envie d'apprendre, tu es autonome et tu es prêt à relever de nouveaux défis.
  </p>
  <p>- Tu es capable de te mettre à la place de quelqu'un d'autre et de donner des réponses correctes à ses questions logistiques.
  </p>
  <p>- Tu as de la patience avec les gens ; tu peux transmettre des connaissances d'une manière agréable. Parfois, ton objectif principal est de faire en sorte que quelqu'un prenne confiance en lui, le résultat final étant moins important.
  </p>
  <p>- Tu as un permis de conduire B et tu peux conduire une camionnette.
  </p>
  <p>- Pour respecter les délais, tu n'hésites pas à travailler le soir ou le week-end.
  </p>
  <p>- Tu organises ton propre travail et tu peux collaborer avec tes collègues sur le fond et la forme.
  </p>
  <p>- Tu parles au moins le français couramment et de préférence aussi le néerlandais et l'anglais.
  </p>
  <p><strong>Qu'est-ce que tu obtiens en retour ?</strong>
  </p>
  <p>Toestand te propose un contrat de ⅘ de durée indéterminée pour la fonction d'assistant logistique aux conditions suivantes :
  </p>
  <p>- Lieu de travail : Bruxelles
  </p>
  <p>- Régime : emploi à temps plein ou à temps partiel (30.4h) - horaire flexible
  </p>
  <p>- Contrat de travail à durée déterminée, contrat de remplacement congé parental
  </p>
  <p>- Echelle de rémunération B1c selon PC 329.01
  </p>
  <p>- Chèques-repas
  </p>
  <p>- Indemnité de déplacement
  </p>
  <p>- Prime de fin d'année
  </p>
  <p>- Des collègues sympathiques
  </p>
  <p>- Le sentiment de participer à la construction et à la prise de décision.
  </p>
  <p><strong>Comment devenir collaborateur logistique chez Toestand ?</strong>
  </p>
  <p>Montre ton expérience en tant qu'employé logistique et dis-nous pourquoi tu aimerais travailler chez Toestand dans un e-mail à <a href="mailto:jobs@toestand.be">jobs@toestand.be</a> avant le 25 mars. Entretiens mardi matin le 28.
  </p>
  
id: 80f5d364-45b6-4169-960b-669bb6faa8f8
published: true
