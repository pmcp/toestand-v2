intro: |
  <p>Diverses associations ont uni leurs force en l'absence de lieu de rencontre, pour créer un nouvel espace de rencontre dans le quartier de Korenbeek. L'école de la rue Korenbeek étant vide depuis un bon moment, nous avons soumis un dossier à la commune de Molenbeek-Saint-Jean pour une occupation temporaire des lieux. C'est ansi que 'Koorenbeek' est né, avec pour but, un offre de services et d'activités pour tous les habitants du quartier.<span class="text_exposed_show"></span>
  </p>
  
article-sections:
  -
    type: section
    in_overview: false
    in_menu: false
    bard:
      -
        type: text
        text: '<p><b><a href="https://atoutsjeunes.org" target="_blank">Atouts Jeunes</a></b>&nbsp;est une organisation où les enfants peuvent aller pour l''aide aux devoirs et d''autres activités extrascolaires.&nbsp;<br></p><p><b><a href="https://www.dewelvaartkapoen.be" target="_blank">Vzw De Welvaartkapoen</a></b>&nbsp;est une organisation qui se concentre sur des activités de l''économie sociale telles que des ateliers de couture et un restaurant social.</p><p><b>Korenbike</b>: Elias s''installe chaque vendredi devant la porte du projet, avec tout son matériel et ses vieux vélos récupérés, et se met à bricoler.</p><p><b><a href="https://www.facebook.com/Bruxseltoi-337960773621892/">Bruxseltoi</a></b>&nbsp;est une organisation qui rassemble des personnes afin qu''elles utilisent leurs talents et leurs compétences pour améliorer la qualité de vie des habitants de Bruxelles.&nbsp;</p><p><b><a href="https://www.facebook.com/nakamavzw">Nakama</a></b>&nbsp;est un collectif de jeunes bruxellois qui veulent travailler pour les enfants et les jeunes de Bruxelles. &nbsp;</p><p><b><a href="https://www.solidarcite.be">Solidarcité</a></b>&nbsp;est un projet de volontariat qui rassemble des jeunes de 16 à 25 ans venant de tous les horizons.&nbsp;</p><p><b>Boekenproject</b>&nbsp;est une petite bibliothèque multilingue pour les enfants et les jeunes du quartier. &nbsp;</p><p><b>Kindersquat</b>&nbsp;est un projet de démocratie participative pour et par les enfants.&nbsp;</p><p><b>Toestand asbl </b>propose des projets avec une finalité sociale dans des bâtiments vides et abandonnés en tant que solution temporaire pour la vacance immobilière d’une part, et le manque d’espace pour des initiatives citoyennes d’autre part. A Korenbeek, on a plutôt un rôle de coordination et de soutien.</p>'
title: 'partenaires Korenbeek'
id: e79e9b7f-d933-4928-91b8-88452ef579c2
slug: partenaires-korenbeek
