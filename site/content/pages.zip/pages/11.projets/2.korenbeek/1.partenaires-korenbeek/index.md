intro: |
  <p>Met het gebrek aan ontmoetingsplaatsen in het achterhoofd sloegen diverse organisaties de handen in elkaar om een nieuwe plek te creëren in de <span class="text_exposed_show">wijk Korenbeek. Het schooltje in de Korenbeekstraat stond al een tijdje leeg en daarom werd er besloten om met een lokaal collectief een dossier in te dienen bij de gemeente Sint-Jans-Molenbeek voor een tijdelijke bezetting. Zo is ' 'Korenbeek' ontstaan, met als doel: diensten en activiteiten aanbieden aan alle buurtbewoners.</span>
  </p>
  
article-sections:
  -
    type: section
    in_overview: true
    in_menu: false
    bard:
      -
        type: text
        text: '<p><b><a href="https://atoutsjeunes.org" target="_blank">Atouts Jeunes</a></b> is een organisatie waar kinderen naartoe kunnen voor huiswerkbegeleiding en andere buitenschoolse activiteiten.&nbsp;<br></p><p><b><a href="https://www.dewelvaartkapoen.be" target="_blank">Vzw De Welvaartkapoen</a></b> is een organisatie die inzet op activiteiten in de sociale economie zoals naaiateliers en een sociaal restaurant.</p><p><b>Korenbike</b>: Elias installeert zich elke vrijdag voor de poort van het project, met al zijn materiaal en gerecupereerde oude fietsen en slaat aan het sleutelen.&nbsp;</p><p><b><a href="https://www.facebook.com/Bruxseltoi-337960773621892/">Bruxseltoi</a></b> is een vzw die mensen samenbrengt en hun talenten en vaardigheden willen inzetten om de levenskwaliteit van Brusselaars te verhogen.&nbsp;</p><p><b><a href="https://www.facebook.com/nakamavzw">Nakama</a></b> is een collectief van jonge Brusselaars die zich willen inzetten voor de kinderen en jongeren van Brussel.&nbsp;</p><p><b><a href="https://www.solidarcite.be">Solidarcité</a></b> is een vrijwilligersproject dat jongeren van 16 tot 25 jaar uit alle lagen van de bevolking samenbrengt.&nbsp;</p><p><b>Boekenproject</b> is een kleine meertalige bibliotheek voor de kinderen en jongeren uit de buurt.&nbsp;</p><p><b>Kindersquat</b> is een participatief democratisch project voor en door kinderen.&nbsp;</p><p><b>Vzw Toestand </b>bedenkt sociaal geïnspireerde projecten voor leegstaande gebouwen als tijdelijke oplossing voor leegstand en verwaarlozing enerzijds, en ruimtegebrek voor burgerinitiatieven anderzijds. In Korenbeek hebben we eerder een coördinerende en ondersteunende rol.&nbsp;</p>'
title: 'Partners Korenbeek'
date: '2020-06-29'
template: detail
hide_from_nav: false
fieldset: page__article
id: 689b29f8-3013-440b-aa72-9311ab203430
