coordinates:
  lat: null
  long: null
address__street: Materialenkaai
address__zip: '1000'
address__city: Brussel
hide_from_nav: false
footer_content: |
  <p>Toestand Academy biedt een reeks workshops aan rond verschillende DIY-thema’s die nuttig kunnen zijn bij het tijdelijk gebruik van een leegstaand gebouw. Elke workshop wordt gegeven door een expert die zijn of haar kennis en ervaring komt delen.
  </p>
  
title: 'Toestand Academy'
fieldset: home
id: 1a4910eb-5e7c-4811-a36f-60e933103edd
