sections:
  -
    type: section__item--activities
    show_title: false
    in_menu: false
    style: carousel
footer_content: |
  <p>Toestand Academy offers a series of workshops in which we teach you how to find your way within various DIY themes that one can face during the temporary use of an empty building. These workshops are given by experts who come to share their knowledge and experience.
  </p>
id: 1a4910eb-5e7c-4811-a36f-60e933103edd
