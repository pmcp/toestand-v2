footer_content: |
  <p>Toestand Academy propose une série d’ateliers dans lesquels vous pouvez apprendre des choses concernant des thèmes de bricolage, qui peuvent être intéressants quand vous êtes confrontés à l’occupation temporaire d’un bâtiment vide. Les ateliers sont organisés par des experts qui viennent partager leurs expériences.
  </p>
  
id: 1a4910eb-5e7c-4811-a36f-60e933103edd
