intro: |
  <p>Al van bij het prille begin van Allee du Kaai kwamen er veel jongeren over de vloer. Om in te spelen op hun noden en hun aanwezigheid zo goed mogelijk te omkaderen werd er een jeugdwerking opgezet. Vandaag is ‘Allee du Kaai Jeunesse’ een belangrijke tak binnen het project.
  </p>
  
title: 'Youth work at Allee Du Kaai'
id: 6d225f09-7c28-4f68-abe5-2148ffeed166
