content_bard:
  -
    type: text
    text: '<p>De activiteiten die plaatsvinden op Allee du Kaai gaan voornamelijk uit van onze partners. Onder hen bevinden zich zowel grote en kleine organisaties als individuen. De rol van Toestand bestaat vooral in het zoeken en vinden van deze partners, het coördineren van de hele site en het bijeenbrengen van mensen met uiteenlopende achtergronden, interesses en kwaliteiten. Alle activiteiten die worden aangeboden, zijn aan vrije bijdrage en toegankelijk voor iedereen!</p>'
title: 'Activiteiten TEST'
published_on: '2020-04-03'
date: '2019-08-08'
template: partners
hide_from_nav: false
fieldset: page__partners
id: 2f154165-79be-4a81-a8c8-54071e44f4af
