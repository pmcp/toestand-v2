content_bard:
  -
    type: text
    text: '<p>Les activités qui se déroulent à l''Allée du Kaai sont principalement réalisées par nos partenaires. Parmi eux figurent des organisations établies et des particuliers. Le rôle de Toestand consiste principalement à trouver des partenaires, à coordonner le site et à créer un mélange divers et inclusif.  Toutes les activités proposées sont à prix libre et accessibles à tous!</p><p><br></p>'
title: Activités
id: 2f154165-79be-4a81-a8c8-54071e44f4af
intro: |
  <p>De activiteiten die plaatsvinden in Allee du Kaai gaan voornamelijk uit van onze partners. Onder hen bevinden zich zowel gevestigde organisaties als individuen. Onze rol bestaat vooral uit het coördineren van de site en het creëren van een gezonde en inclusieve mix. Benieuwd naar onze partners en hun activiteiten? Hieronder vind je een overzicht van wie we allemaal onderdak bieden. Alle activiteiten die worden aangeboden, zijn aan vrije bijdrage en toegankelijk voor iedereen.
  </p>
  
slug: activites-allee-du-kaai
