intro: |
  <p>Toestand a collaboré avec InfoQuartier Mâche (Suisse) et la Kosovo Architecture Foundation (Pristina). 25 Belges, 15 Suisses et 5 à 20 Kosovars se sont mouillés la chemise pendant une semaine. Ensemble, nous avons converti l'échangeur de chaleur abandonné de Termokos en centre socioculturel alternatif "Termokiss".<br>
  </p>
  
id: 7d46e8f3-3000-456d-90a9-b3a3ec92893c
