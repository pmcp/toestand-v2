intro: |
  <p>À la demande de l'Associación Anaquerando Gitana, nous nous sommes rendus à Grenade. Nous y rénovions un parc public avec des associations locales. Il a été doté de couleurs arc-en-ciel - d'où son nom - et réaménagé en fonction des besoins de ses utilisateurs. Avec eux, nous avons construit des aires de jeux pour les jeunes et les personnes agées, des infrastructures sportives et des jeux. Ensuite nous avons remis à disposition un espace intérieur.<br>
  </p>
  
id: 804c79ab-6738-4e2e-842c-73cdf993c49a
