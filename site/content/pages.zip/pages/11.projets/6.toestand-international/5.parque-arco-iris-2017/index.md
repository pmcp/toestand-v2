intro: |
  <p>Op vraag van Associación Anaquerando Gitana gingen we naar Granada. Daar fristen we met lokale verenigingen een publiek park op. Het kreeg regenboogkleuren - vandaar de naam - en werd terug ingericht naargelang de noden van haar bezoekers. Samen met hen bouwden we speelruimtes voor jong en oud, sport- en spelinfastructuur en stelden we een binnenruimte opnieuw ter beschikking.<br>
  </p>
article-sections:
  -
    type: section
    section_title: ENGLISH
    in_overview: true
    in_menu: false
    bard:
      -
        type: text
        text: '<p>At the request of Associación Anaquerando Gitana we went to Granada. There we renovated a public park with local associations. It was given rainbow colours - hence the name - and redesigned according to the needs of its visitors. Together with them, we built playgrounds for young and old, sports and games facilities and made an indoor space available again.</p><ul><li>Partners: Motivated individuals, Prishtina Architecture week&nbsp;<br></li><li>From 30.06.17 tot 12.07.17<br></li><li>45 people (from Spain, Belgium, Italy, France, etc)<br></li><li>Pictures on <a href="https://www.flickr.com/photos/parquedelarcoiris" target="_blank">Flickr</a><br></li><li>Video on <a href="https://www.facebook.com/Toestand/videos/1746532312061415/" target="_blank">Facebook</a><br></li></ul><p><br></p>'
title: 'Parque arco iris (2017)'
date: '2020-02-27'
template: detail
hide_from_nav: false
fieldset: page__article
id: 804c79ab-6738-4e2e-842c-73cdf993c49a
