intro: |
  <p>Le projet Termokiss a fait bouger les gens dans les Balkans. Après notre passage à Pristina, nous avons reçu une demande de transformation d'un bâtiment abandonné à Tetova, au nord de la Macédoine, avec et pour jeunes locaux. Nous nous sommes jetés sur une ancienne station de radio (aujourd'hui appelée Tetova Socio Cultural Space) et avons construit un skate parc avec une à côté de la gare routière.<br>
  </p>
  
id: f369e273-f02d-44c0-95ae-7441aa825481
