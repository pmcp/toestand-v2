intro: |
  <p>Le Réseau des Balkans de Toestand continue de s'étendre. Après Pristina et Tetova, les jeunes de Tirana nous ont également demandé de construire un lieu de rencontre socioculturel. Avec des jeunes des quatre pays, nous avons transformé une usine de tracteurs abandonnée à Uzina en un lieu ouvert à l'initiative et l'expérimentation.<br>
  </p>
  
id: 3b8f2826-03e5-4288-9789-c8443958a19b
