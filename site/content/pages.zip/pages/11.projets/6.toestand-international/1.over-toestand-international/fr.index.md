intro: |
  <p>Le premier projet international a eu lieu à Kremenchuk (Ukraine), où un cinéma abandonné a été transformé en centre de jeunesse. Dans les années suivantes, une structure en béton a été transformée en centre socioculturel alternatif à Prishtina (Kosovo), une place a été revitalisée à Grenade (Espagne), et Tetova (Macédoine) a reçu un nouveau skate park et un centre socioculturel.
  </p>
  <p>Toestand ne plante que des graines. Ainsi, à la fin de chaque période de construction intensive, les sites sont laissés entièrement à la population locale et en particulier aux jeunes déjà impliqués. Cette méthode de travail porte ses fruits. Le centre socioculturel alternatif de Prishtina, appelé Termokiss, est plus que jamais en pleine activité. Dans "l'espace social et culturel Tetova", les activités se succèdent.
  </p>
  <p><br>
  </p>
  
title: 'A propos de Toestand International'
id: e53c5b97-54b1-4a4c-81e5-f7fa1e97ff2c
