intro: |
  <p>Cultural Di@logue nodigde Toestand in de zomer van 2015 uit om in Kremenchuk (Oekraïne) deel te nemen aan Transformers: een festival waarin Sovjet-architectuur een nieuwe invulling kreeg. . Op een week tijd bouwden 12 Belgische vrijwilligers en een team van ca 15 Oekraïners een verlaten cinema om tot een jeugdculturele zone. Na de winter vonden zij een nieuwe plek en werden ze #Adapter’.<br>
  </p>
article-sections:
  -
    type: section
    section_title: ENGLISH
    in_overview: true
    in_menu: false
    bard:
      -
        type: text
        text: '<p>Cultural Di@logue invited Toestand in the summer of 2015 to participate in Transformers in Kremenchuk (Ukraine): a festival about the re-appropriation of old Soviet architecture. In one week time, 12 Belgian volunteers and a team of about 15 Ukrainians converted an abandoned cinema into a cultural youth space. After the winter they found a new place and became #Adaptors''.</p><ul><li>Partners: Cultural Dialog (Kremenchuk, Ukraine)&nbsp;</li><li>From 07.07.15 to 15.07.15&nbsp;</li><li>25 people (from Ukraine &amp; Belgium) </li></ul><p><br></p>'
title: 'Transformers (2015)'
date: '2020-02-27'
template: detail
hide_from_nav: false
fieldset: page__article
id: 74d61c9f-a1e2-4315-8e6e-bf1d46f3b89f
