intro: |
  <p>Cultural Di@logue a invité Toestand à l'été 2015 pour participer à "Transformers" in Kremenchuk (Ukraine) : un festival dans lequel l'architecture soviétique a été revisitée. En l'espace d'une semaine, 12 volontaires belges et une équipe d'une quinzaine d'Ukrainiens ont transformé un cinéma abandonné en un espace culturel pour les jeunes. Après l'hiver, ils ont trouvé un nouvel endroit sous le nom "Adapter".<br>
  </p>
  
id: 74d61c9f-a1e2-4315-8e6e-bf1d46f3b89f
