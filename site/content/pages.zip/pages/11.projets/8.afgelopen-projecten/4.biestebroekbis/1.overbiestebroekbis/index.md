article-header__image:
  - /assets/BBB/56396082_2164046053908154_8854254339754033152_o.jpg
intro: |
  <p>BiestebroekBis is een spontane actiezone in Anderlecht. Binnen het wijkcontract ‘Biestebroek’ bliezen we eerst de leegstaande kantoorgebouwen van [PIAS ] nieuw leven in. Maar ondanks een sterk groeiende dynamiek, moesten we al snel op zoek naar een nieuwe locatie. Na een grondige zoektocht kwamen we terecht in de leegstaande benedenverdieping van de Academie voor Beeldende Kunsten. Net als op de vorige locatie, maken we deze ruimtes beschikbaar voor sociaal en cultureel initiatief uit de buurt. In tegenstelling tot Allee du Kaai werkt BiestebroekBis niet met vaste partners die op wekelijkse basis activiteiten aanbieden, maar ligt de focus veeleer op het evenementiële. Zo deed BiestebroekBis o.a. dienst als locatie voor ‘Dag van de Jeugdhuizen’, als repetitieruimte voor theatercollectieven en fanfares, als concertruimte,... Zelf organiseert BiestebroekBis ook bouw- en baravonden en maandelijkse filmvertoningen.
  </p>
  <p>De buurt rond Sint-Guido is erg divers. In de Gustaaf Vanden Berghestraat wonen er ook behoorlijk wat gepensioneerden. We trachten ook hen een plaats te geven binnen de ruimte en de werking (whist-avonden, brocante). Maar rond Sint-Guido hangen er altijd jongeren rond, dus ook zij zijn een doelgroep. Op geregelde tijdstippen komen we dan ook naar buiten om activiteiten in de publieke ruimte te organiseren.
  </p>
  <p>Onze bar op woensdag, de Biesteclub, is de plek waar zowel buren als andere geïnteresseerden met ons en met elkaar kennis kunnen maken. Daar zetten we in op een warm onthaal en een ongedwongen sfeer. We hanteren ook een laagdrempelige prijzenpolitiek: koffie, thee en water zijn gratis, andere dranken bieden we aan aan erg democratische prijzen. Kom gerust langs voor een praatje, een glaasje en wie weet, een leuk idee voor een activiteit?
  </p>
  
title: 'Over BiestebroekBis'
date: '2019-09-05'
template: detail
hide_from_nav: false
fieldset: page__article
id: fbce89bc-463a-418a-a7ad-44fa1f35d4d0
