intro: |
  <p>Een aflopend chronologisch overzicht van al onze projecten van tijdelijk ruimtegebruik, in Brussel en de rand. Van korte, punctuele activiteiten ('momenten'), tot langlopende bezettingen van grotere gebouwen en openbare ruimte ('Spontane Actiezones').
  </p>
  <p><br>
  </p>
  
title: 'Chronologie des projets'
id: 482e707d-6226-4cbc-86af-0bf458ac9a17
published: false
slug: chronologiedesprojets
