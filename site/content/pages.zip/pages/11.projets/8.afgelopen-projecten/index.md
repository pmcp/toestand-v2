article-sections:
  -
    type: section
    section_title: tijdslijn
    in_overview: true
    in_menu: false
title: 'Afgelopen Projecten'
date: '2019-10-31'
template: project-overview
hide_from_nav: false
fieldset: page__article
id: d2ccba67-df8b-4114-8858-fac45a3a1c79
