title: 'Over Bara 142'
date: '2020-03-25'
template: detail
hide_from_nav: false
fieldset: page__article
id: 5dd00313-7553-4805-853d-4c5f876d44f4
