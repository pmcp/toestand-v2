article-header__image:
  - /assets/toestand/49585101141_c7a8138862_o.jpg
intro: |
  <p>Een erfeniskwestie, een faillissement, een afgewezen bouwaanvraag, een aanslepende procedure... Leegstand kent heel wat uiteenlopende oorzaken. Wat deze ook mogen zijn, één ding is zeker: deze leegstaande ruimtes kunnen veel zinvoller worden besteed! <br>
  </p>
article-sections:
  -
    type: section
    section_title: 'Leegstand, van bedreiging tot meerwaarde.'
    in_overview: true
    in_menu: false
    bard:
      -
        type: text
        text: '<p>Leegstand brengt heel wat nadelige gevolgen met zich mee. Zo takelt een leegstaand pand snel af en trekt leegstand vandalisme en criminaliteit aan, wat de buurt een onveilig imago oplevert. Door in te tekenen op tijdelijk ruimtegebruik, onder deskundig toezicht van vzw Toestand, wordt deze dreiging omgedraaid in een positief verhaal.<br>Tijdelijk ruimtegebruik is de overgangsfase waarbij een ongebruikte of onderbenutte ruimte een tijdelijke invulling krijgt in afwachting van de definitieve ingebruikname. Door haar tijdelijk en experimenteel karakter kan dit concept snel inspelen op de sociale, culturele en ecologische noden van de maatschappij.</p>'
  -
    type: section
    section_title: 'Voordelen van tijdelijk ruimtegebruik'
    in_overview: true
    in_menu: false
    bard:
      -
        type: text
        text: '<p>Voordelen voor de eigenaar:&nbsp;</p><ul><li>Geen kost aan leegstandtaks en boetes&nbsp;</li><li>Bijdrage tot de heropleving van de buurt&nbsp;</li><li>Sociale controle = beveiliging tegen vandalisme en ongeoorloofde bezoeken&nbsp;</li><li>Onderhoud van het gebouw&nbsp;</li><li>Een mogelijk communicatiekanaal voor een toekomstige projectontwikkeling<br></li></ul><p>Voordelen voor de gebruiker:&nbsp;</p><ul><li>Toegang tot betaalbare ruimte&nbsp;</li><li>Ondersteuning en omkadering door Toestand&nbsp;</li><li>Een kans om een project uit te testen en waar te maken<br></li></ul><p>Voordelen voor de buurt en de stad:&nbsp;</p><ul><li>Heropleving van de buurt&nbsp;</li><li>Versterking van het sociaal weefsel&nbsp;</li><li>Burgerparticipatie&nbsp;</li><li>De mogelijkheid om te experimenteren met toekomstige stedelijke ontwikkelingen<br></li></ul>'
  -
    type: section
    section_title: 'Een contract met de eigenaar'
    in_overview: true
    in_menu: false
    bard:
      -
        type: text
        text: '<p>Voor het sluiten van een overeenkomst met de eigenaar baseren we ons op het contracttype: bezetting ter bede. Dit is een specifieke contractvorm die flexibiliteit inzake opzegtermijn, soort activiteit, verzekerings-en aansprakelijkheidskwesties en duurtijd toelaat. Dit type contract brengt m.a.w. niet dezelfde verplichtingen als een normaal huurcontract met zich mee.</p><p>Wenst u uw eigendom voor tijdelijk gebruik ter beschikking te stellen, in afwachting van andere plannen? Misschien is Toestand dan uw ideale partner! Neem contact met ons op voor meer info:&nbsp;<a href="mailto:info@toestand.be">info@toestand.be</a>.</p>'
  -
    type: section
    section_title: 'Ruimte nodig?'
    in_overview: true
    in_menu: false
    bard:
      -
        type: text
        text: '<p>Ben je op zoek naar ruimte om jouw sociaal project te verwezenlijken? Laat het ons weten! Misschien vind je wel ergens een plaatsje binnen onze muren. Helaas kunnen we niet iedereen een ruimte aanbieden, maar hopelijk kunnen we je toch verder helpen met advies of doorverwijzen. Neem contact met ons op voor meer info:&nbsp;<a href="mailto:info@toestand.be">info@toestand.be</a>.</p><p>Denk je eraan om zelf een pand in gebruik te nemen maar je weet niet goed hieraan te beginnen? Geen nood, je vindt vast veel antwoorden op jouw vragen in ons boek "<a href="https://toestand.be/leegstond">Leegstond</a>", waarin we onze tips en ervaringen hebben gebundeld.</p>'
title: 'Ruimte nodig of ter beschikking?'
date: '2019-04-23'
template: detail
hide_from_nav: false
fieldset: page__article
id: 65b45615-e06e-4696-9082-e55bba84b7d2
