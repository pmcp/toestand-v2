intro: |
  <p>Une question d’héritage, une faillite, une demande de permis de construire rejetée, une procédure qui s’éternise... Les causes d’une inoccupation sont nombreuses et variées. Quoi qu’il en soit, une chose est sûre : ces espaces vacants peuvent être affectés de façon beaucoup plus judicieuse !<br>
  </p>
  
article-sections:
  -
    type: section
    section_title: 'Inoccupation : de la menace à la valeur'
    in_overview: true
    id_on_page: projectvoorstel
    in_menu: false
    bard:
      -
        type: text
        text: |
          <p>L’inoccupation entraîne de nombreuses conséquences négatives. Par exemple, un immeuble
          
          vacant se dégrade rapidement et les locaux vides
          attirent le vandalisme et la criminalité, créant une
          impression d’insécurité dans le quartier. En optant
          pour une occupation temporaire de l’espace sous
          la supervision experte de l’ASBL Toestand, cette
          menace se transforme en une histoire positive.</p><p>L’occupation temporaire de l’espace est la phase
          
          transitoire au cours de laquelle un espace inutilisé ou sous-utilisé se voit attribuer une affectation
          
          temporaire en attendant son utilisation définitive. En
          raison de son caractère temporaire et expérimental,
          ce concept peut rapidement répondre aux besoins
          sociaux, culturels et écologiques de la société.</p>
          
  -
    type: section
    section_title: 'Avantages de l''usage temporaire'
    in_overview: true
    bard:
      -
        type: text
        text: |
          <p>Pour le propriétaire :&nbsp;</p><ul><li>pas de frais d’inoccupation et d’amendes&nbsp;</li><li>contribution au renouveau du quartier&nbsp;</li><li>protection contre le vandalisme et les visites
          non autorisées&nbsp;</li><li>entretien bon marché du bâtiment&nbsp;</li><li>canal de communication potentiel pour un
          développement futur de projet.<br></li></ul><p>Pour l’utilisateur :&nbsp;</p><ul><li>accès à un espace accessible&nbsp;</li><li>opportunité de tenter un projet
          et de le réaliser&nbsp;</li><li>soutien et encadrement par
          Toestand.<br></li></ul><p>Pour le quartier et la ville :&nbsp;</p><ul><li>revitalisation du quartier&nbsp;</li><li>renforcement du tissu social&nbsp;</li><li>participation citoyenne&nbsp;</li><li>possibilité d’expérimenter de futurs
          développements urbains.</li></ul>
          
    in_menu: false
  -
    type: section
    section_title: 'Un contrat avec le propriétaire'
    in_overview: true
    in_menu: false
    bard:
      -
        type: text
        text: |
          <p>Pour conclure un accord avec le propriétaire,
          nous nous basons sur contrat type : le contrat
          d’occupation précaire. Il permet une flexibilité en
          ce qui concerne la durée de l’occupation, le délai
          de rétractation et les types d’activités proposées.
          Il clarifie les questions relatives à la gestion du lieu
          en matière d’assurance et de responsabilité. En
          d’autres termes, ce type de contrat n’entraîne pas
          les mêmes obligations qu’un bail classique.</p><p>Vous souhaitez mettre votre propriété à disposition pour un usage temporaire, en attendant d'une affectation définitive ? Alors peut-être que Toestand est votre partenaire idéal ! Contactez-nous pour plus d'informations : <a href="info@toestand.be">info@toestand.be</a>.</p>
          
  -
    type: section
    section_title: 'Besoin d''espace?'
    in_overview: true
    in_menu: false
    bard:
      -
        type: text
        text: '<p>Vous cherchez un espace pour réaliser votre projet à finalité sociale ? Faites-le nous savoir ! Peut-être trouverez-vous une place quelque part dans nos murs. Nous ne pouvons malheureusement pas offrir un espace à tout le monde, mais nous espérons pouvoir vous aider en vous conseillant ou en vous orientant. Contactez-nous pour plus d''informations : <a href="info@toestand.be">info@toestand.be</a>.</p><p>Vous envisagez d''occuper un bâtiment vous-même mais vous ne savez pas par où commencer ? Ne vous inquiétez pas, si vous lisez et comprenez le néerlandais, vous trouverez certainement de nombreuses réponses à vos questions dans notre livre "<a href="https://toestand.be/fr/leegstond">Leegstond</a>", dans lequel nous avons compilé nos conseils et expériences (uniquement en néerlandais!).</p>'
title: 'Besoin d''espace ou de l''espace à disposition?'
id: 65b45615-e06e-4696-9082-e55bba84b7d2
