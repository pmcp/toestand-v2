intro: |
  <p>Toestand est née d'un groupe de personnes qui, au début, ont tout fait volontairement. Encore aujourd'hui, nous ne pourrions pas exister sans nos bénévoles. Des centaines de personnes s'investissent dans nos projets tout au long de l'année!
  </p>
  
article-sections:
  -
    type: section
    section_title: 'Devenir bénévole?'
    in_overview: true
    bard:
      -
        type: text
        text: |
          <p>En plus des employés salariés, Toestand est également soutenu par une centaine de bénévoles. Ils contribuent à réaliser les projets et à déterminer l'identité de l'organisation. Ensemble, nous essayons constamment de remettre en question nos méthodes et nous continuons à construire une organisation transparente fondée sur des valeurs et des principes solides. Ensemble, nous réfléchissons sur la ville. Ensemble, nous sommes Toestand!&nbsp;</p><p>Il n'est pas nécessaire d'être un constructeur  habile ou de répondre à un certain profil pour contribuer. Nous considérons chaque personne comme une valeur ajoutée pour notre organisation.
          
          Pour rester à jour, vous pouvez visiter notre groupe facebook privé "<a href="https://www.facebook.com/groups/720876511294967/" target="_blank">Bénévoles Toestand</a>".</p>
          
    in_menu: false
title: Bénévolat
id: 8ced04cb-d8c6-4eeb-960e-35e64a55eac6
