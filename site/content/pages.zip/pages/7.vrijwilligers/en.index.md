intro: |
  <p>Toestand is ontstaan uit een groep van mensen die in het begin alles vrijwillig deden. Wij zouden ook nu niet zonder vrijwilligers kunnen bestaan. Honderden mensen zetten zich gedurende het jaar in om onze Spontane Actie Zones draaiende te houden.
  </p>
article-sections:
  -
    type: section
    section_title: 'Vrijwilliger worden?'
    in_overview: true
    bard:
      -
        type: text
        text: |
          <p>Naast vaste medewerkers wordt Toestand ook gedragen door een honderdtal vrijwilligers. Ze geven de projecten mee vorm en bepalen de identiteit van de organisatie. Samen trachten we onze methodes voortdurend in vraag te stellen en verder te bouwen aan een duidelijke organisatie gebouwd op sterke waarden en principes. Samen denken we na over de stad. Samen maken we Toestand.&nbsp;</p><p>Je hoeft niet goed te kunnen bouwen of in een bepaald plaatje te passen om bij te dragen. Wij zien elke persoon als een meerwaarde voor onze organisatie.
          
          Om op de hoogte te blijven kan je terecht op onze private facebookgroep <a href="https://www.facebook.com/groups/720876511294967/" target="_blank">‘Bénévoles Toestand’</a>.</p>
    in_menu: false
id: 8ced04cb-d8c6-4eeb-960e-35e64a55eac6
