intro: |
  <p>Les gens pensent généralement à la négligence et à la mauvaise gestion lorsque des bâtiments sont vides et inoccupés, mais Toestand préfère se concentrer sur les possibilités de la vacance immobilière !
  </p>
article-sections:
  -
    type: section
    section_title: 'Notre mission et vision'
    in_overview: true
    bard:
      -
        type: text
        text: '<p>Toestand s''efforce de créer une ville inclusive et solidaire dans laquelle l''espace est abordable et accessible à tous. On constate qu''aujourd''hui l''espace est tout sauf équitablement réparti. De nombreuses personnes souffrent d''un manque d''espace, alors que des millions de mètres carrés sont littéralement inoccupés. On pourrait même parler d''une superficie totale qui égale à une&nbsp;<a href="https://www.leegbeek.brussels">20ème commune</a> à Bruxelles ... Afin de lutter contre le gaspillage d''une part et de rendre l''espace accessible d''autre part, nous transformons des lieux vides et déserts en lieux de rencontre socioculturels temporaires. Nous ne nous contentons pas de concevoir ces lieux, mais nous travaillons également avec un large réseau de partenaires allant d''organisations établies à des habitants de quartier engagés. Nous leur offrons l''espace nécessaire à la réalisation de leur projet et leur fournissons le cadre nécessaire à cette fin.</p>'
    id_on_page: 'Missie & Visie'
    in_menu: false
  -
    type: section
    section_title: 'Qui est Toestand?'
    in_overview: true
    bard:
      -
        type: text
        text: '<p>Toestand est une asbl bruxelloise bilingue spécialisée dans l''usage temporaire de surfaces inutilisées. L''asbl a été fondée en 2012 par un groupe de jeunes bruxellois engagés. En quelques années seulement, nous sommes devenus une organisation professionnelle qui emploie actuellement plus que dix employés à mi-temps, répartis sur cinq projets. En plus de nos employés fixes, nous pouvons compter sur un vaste réseau de partenaires et de bénévoles qui travaillent avec nous au quotidien pour réaliser notre rêve.</p><p>Découvrez notre travail par ce petit reportage, fait par Project B, une initiative des étudiants bruxellois et non bruxellois de la VUB.&nbsp;</p>'
      -
        type: video
        value: 'https://youtu.be/lN3HNYceUmU'
    id_on_page: 'Wie is Toestand?'
    in_menu: false
  -
    type: section
    section_title: 'Pourquoi Toestand?'
    in_overview: true
    bard:
      -
        type: text
        text: '<p>En transformant les espaces vides en centres socioculturels temporaires, ou plutôt en "zones d''action spontanée", Toestand veut utiliser l''espace - autrement perdu - d''une manière significative pour la ville et ses habitants. Bruxelles compte quelque 6,5 millions de mètres carrés d''immeubles de bureaux, de logements, de locaux industriels, etc. vides. En même temps, de nombreuses organisations et personnes recherchent un endroit abordable pour réaliser leur projet. En reliant ces deux éléments, Toestand veut montrer comment l''inoccupation peut renforcer le tissu urbain en créant des opportunités et en rapprochant les gens, indépendamment de leurs origines ou de leurs possibilités financières. De cette façon, l''inoccupation ne contribue pas seulement au développement, mais aussi à la rencontre des gens.&nbsp;</p>'
      -
        type: video
        value: 'https://youtu.be/M6omxlwuBXI'
    id_on_page: 'Wat is Toestand?'
    in_menu: false
  -
    type: section
    section_title: 'Usage temporaire'
    in_overview: true
    bard:
      -
        type: text
        text: |
          <p>L'usage temporaire de l'espace est la phase transitoire pendant laquelle un espace inutilisé ou sous-utilisé est temporairement occupé en attendant son affectation définitive. Son caractère temporaire et expérimental permet de répondre rapidement aux besoins sociaux, culturels et écologiques de la société.
          
          L'inoccupation a de nombreuses conséquences négatives. Par exemple, une propriété inoccupée décline rapidement et l'inoccupation attire le vandalisme et la criminalité, ce qui est mauvais pour les propriétaires et le voisinage. En souscrivant à un usage temporaire et transitoire de l'espace, sous la supervision experte de l'asbl Toestand, cette menace se transforme en une opportunité positive.</p>
    id_on_page: 'Tijdelijk gebruik?'
    in_menu: false
  -
    type: section
    section_title: Historique
    in_overview: true
    in_menu: false
    bard:
      -
        type: text
        text: |
          <p>À la recherche d'un espace pour faire la fête, nous, jeunes bruxellois engagés, sommes entrés pour la première fois en contact avec l'inoccupation. Des espaces qui ne représentent "rien" et peuvent donc encore devenir n'importe quoi... Cela nous a fait rêver, mais surtout cela nous a fait réfléchir. Car que faire si les classes moyennes aisées ont déjà du mal à trouver de la place pour faire leur truc ? Où peuvent aller les habitants de la ville qui ont moins de possibilités ?&nbsp;</p><p>54Kolaktiv a été créé en 2007 autour de la place Sainte-Cathérine au centre de Bruxelles. Ce qui a commencé comme un collectif de DJs bruxellois et flamands s'est rapidement transformé en un groupe diversifié d'artistes, d'organisateurs, de musiciens, de graphistes,... Le collectif a été régulièrement confronté au manque d'espace pour ses activités. 
          
          Les centres culturels et autres espaces existants posaient souvent des contraintes, tandis que les alternatives commerciales étaient financièrement irréalisables. Assez vite, nous avons rêvé de notre propre lieu. Un endroit abordable, où les jeunes peuvent aller aux toilettes gratuitement, où vous ne devez pas payer trois euros pour une boisson, où le loyer n'est pas si élevé que vos amis ne peuvent pas se permettre l'entrée. Et où un contact solide peut être développé avec les habitants de quartier. 
          
          Les membres de 54Kolaktiv étaient conscients du contexte de la grande ville. Les bâtiments vides, en particulier, se sont révélés être une possibilité de trouver ce genre d'espaces. Partager l'espace obtenu avec d'autres groupes de la ville en dehors du collectif, et certainement avec les groupes les plus vulnérables, a été la raison de la création d'une nouvelle association sans but lucratif : Toestand.&nbsp;</p><p>Depuis 2012, nous avons trouvé d'innombrables bâtiments vides dans la ville, des casinos aux biscuiteries, des zones industrielles vacantes aux bâtiments scolaires. Nous avons souvent commencé par un "Moment", un événement organisé par et pour tout le monde. Régulièrement, nous avons aussi trouvé des endroits pour une période plus longue, et nous pouvions vraiment y faire notre truc. Nous les avons ensuite rebaptisés "zones d'action spontanée" (ZAS). 
          
          Toestand a réalisé de nombreux projets temporaires depuis sa création, d'une durée de quelques heures à plusieurs années. Nous avons souvent pris l'initiative, en travaillant généralement avec un large réseau d'organisations socioculturelles. 
          
          En 2014, nous avons recruté nos premiers collaborateurs pour le projet Allee Du Kaai et grâce à une subvention pour notre travail de jeunesse expérimental. Aujourd'hui (2020), nous comptons 13 employés permanents (la plupart à mi-temps) et une centaine de bénévoles, répartis sur plusieurs projets.&nbsp;</p>
  -
    type: section
    section_title: Prix
    in_overview: true
    in_menu: false
    bard:
      -
        type: text
        text: '<p>Toestand a remporté une nomination pour le prix Golden Ketjes de la VGC en 2012 pour l''ensemble de ses activités et ses projets, une nomination pour les Mixity Awards de l''asbl visit.brussels en 2017 pour la diversité et l''inclusivité du projet Allee Du Kaai, et le Prix flamand de la Culture Ultima 2016, pour son travail d''animation socioculturelle des adultes.</p>'
      -
        type: video
        value: 'https://youtu.be/qCPlJBSbmdw'
      -
        type: text
        text: '<p>Extrait du rapport de motivaton:&nbsp;</p><p><i>”Les actions de Toestand ont un effet catalyseur : elles mettent les personnes en contact avec des initiatives socioculturelles, elles font se rencontrer les gens au-delà des clivages, elles tentent de lancer une dynamique sociale dans les quartiers qui ont été exclus de la société, elles impliquent la population dans la création de nouveaux espaces publics... Toestand nage en quelque sorte à contre-courant, en mettant en avant le squattage comme une alternative positive, comme un point de départ pour une amélioration, pour un renouveau par le bas...”&nbsp;</i></p>'
title: 'A propos de Toestand'
id: 913b22fc-c5de-4a73-afc6-676800c26eff
