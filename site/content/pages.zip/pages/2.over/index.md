article-header__image:
  - /assets/toestand/over-toestand-banner.jpg
intro: |
  <p>Mensen denken bij leegstand doorgaans aan verwaarlozing en wanbeheer, maar Toestand richt zich liever op de mogelijkheden ervan!
  </p>
  
article-sections:
  -
    type: section
    section_title: 'Onze missie & visie'
    in_overview: true
    bard:
      -
        type: text
        text: '<p>Toestand streeft naar een inclusieve en solidaire stad waarin ruimte voor iedereen toegankelijk is. We stellen vast dat ruimte vandaag allesbehalve eerlijk verdeeld is. Heel wat mensen ervaren een tekort aan ruimte, terwijl er letterlijk miljoenen vierkante meters leeg staan. Om enerzijds verspilling tegen te gaan en anderzijds ruimte toegankelijk te maken, bouwen we leegstaande en verlaten plekken om tot tijdelijke, sociaal-culturele ontmoetingsplekken. We geven deze plekken niet alleen vorm, maar werken samen met een breed netwerk aan partners gaande van gevestigde organisaties tot geëngageerde buurtbewoners.&nbsp;We bieden hen de ruimte om hun project waar te maken en zorgen hierbij voor de nodige omkadering.</p>'
    id_on_page: 'Missie & Visie'
    in_menu: false
  -
    type: section
    section_title: 'Wie is Toestand?'
    in_overview: true
    bard:
      -
        type: text
        text: '<p>Toestand is een tweetalige Brusselse vzw, gespecialiseerd in tijdelijk ruimtegebruik. De vzw werd in 2012 opgericht door een groep jonge geëngageerde Brusselaars. Op enkele jaren tijd groeiden we uit tot een gevestigde organisatie die momenteel (2020) dertien halftijdse werknemers tewerkstelt, verspreid over een vijftal projecten. Naast onze vaste medewerkers kunnen we rekenen op een uitgebreid netwerk aan partners en vrijwilligers die dagelijks met ons onze droom waarmaken.</p><p>Ontdek hieronder een kort voorstellingsfilmpje van<a href="https://projectbrussel.weebly.com" target="_blank"> Project B</a>,&nbsp;een initiatief van Brusselse en niet-Brusselse studenten aan de VUB.</p>'
      -
        type: video
        value: 'https://youtu.be/lN3HNYceUmU'
    id_on_page: 'Wie is Toestand?'
    in_menu: false
  -
    type: section
    section_title: 'Waarom Toestand?'
    in_overview: true
    bard:
      -
        type: text
        text: '<p>Door leegstaande ruimtes om te bouwen tot tijdelijke sociaal-culturele centra of beter gezegd ‘Spontane Actie Zones’, wil Toestand de – anders verloren – ruimte op een zinvolle manier inzetten voor de stad en haar bewoners. In Brussel staat er zo’n 6,5 miljoen vierkante meter leeg aan kantoorgebouwen, woningen, industriële panden,…&nbsp;Tegelijk zijn heel wat organisaties en individuen op zoek naar een betaalbare plek om hun project waar te maken.&nbsp;Door deze twee zaken aan elkaar te koppelen wil Toestand aantonen hoe leegstand het stadsweefsel kan versterken door enerzijds kansen te creëren en anderzijds mensen, los van hun achtergrond of financiële mogelijkheden, samen te brengen. Op deze manier draagt leegstand niet alleen bij tot ontplooiing, maar ook tot ontmoeting.&nbsp;</p>'
      -
        type: video
        value: 'https://youtu.be/M6omxlwuBXI'
    id_on_page: 'Wat is Toestand?'
    in_menu: false
  -
    type: section
    section_title: 'Tijdelijk gebruik'
    in_overview: true
    bard:
      -
        type: text
        text: '<p>Tijdelijk ruimtegebruik is de overgangsfase waarbij een ongebruikte of onderbenutte ruimte een tijdelijke invulling krijgt in afwachting van de definitieve ingebruikname. Door het tijdelijk en experimenteel karakter kan snel worden ingespeeld op de sociale, culturele en ecologische noden van de maatschappij.</p><p>Leegstand brengt heel wat nadelige gevolgen met zich mee. Zo takelt een leegstaand pand snel af en trekt leegstand vandalisme en criminaliteit aan, wat slecht is zowel voor de eigenaars als voor de buurt. Door in te tekenen op tijdelijk ruimtegebruik, onder deskundig toezicht van vzw Toestand, wordt deze dreiging omgezet in een positieve mogelijkheid.</p>'
    id_on_page: 'Tijdelijk gebruik?'
    in_menu: false
  -
    type: section
    section_title: Geschiedenis
    in_overview: true
    in_menu: false
    bard:
      -
        type: text
        text: '<p>Op zoek naar ruimte om te feesten kwamen we als jonge geëngageerde Brusselaars voor het eerst in aanraking met leegstand. Ruimtes die ‘niets’ voorstellen en daardoor nog alles kunnen worden… Het zette ons aan het dromen, maar vooral ook aan het nadenken. Want wat als de gegoede middenklasse al moeilijk aan ruimte komt om z’n ding te kunnen doen? Waar kunnen stadsgenoten met minder kansen dan terecht?&nbsp;</p><p><b>54Kolaktiv </b>ontstond in 2007 rond het Sint-Katelijneplein in het centrum van Brussel. Wat begon als een DJ-collectief van Brusselse en Vlaamse jongeren, groeide snel uit tot een diverse groep van kunstenaars, organisatoren, muzikanten, grafisch ontwerpers,... Regelmatig werd het collectief geconfronteerd met het gebrek aan ruimte voor hun activiteiten.&nbsp;<br></p><p>Bestaande gemeenschapscentra en andere ruimtes waren vaak té beperkend in gebruik, commerciële alternatieven dan weer financieel onhaalbaar. Al snel droomden we over een eigen locatie. Een betaalbare plaats, waar jongeren gratis naar het toilet kunnen gaan, waar je geen drie euro moet betalen voor een drankje, waar de huur niet zo hoog is dat je vrienden het ingangsticket niet meer kunnen betalen. En waar een degelijk contact kan worden uitgebouwd met buurtbewoners.&nbsp;</p><p>De leden van 54Kolaktiv waren zich bewust van de context van de grootstad. In het bijzonder bleken leegstaande gebouwen een mogelijke kans te vormen om dit soort ruimtes te vinden. Het delen van de veroverde ruimte met andere groepen uit de stad buiten het collectief, en zeker met de meest kwetsbare groepen werd de aanleiding voor het oprichten van een nieuwe vzw in 2012: Toestand.&nbsp;</p><p>Toestand kwam dus voort uit de zoektocht naar ruimte van jonge geëngageerde creatieve Brusselaars. Ruimte voor creatie, ontmoeting, dialoog en experiment. Een droom van een plaats om je ‘Toestand’ uit te drukken zonder beperkingen. Een plaats waar je je ding kon doen, los van de maatschappelijke verwachtingen en economische beperkingen. Deze plaats vonden we in leegstaande plekken in de stad, van casino’s tot koekjesfabrieken, van leegstaande industrieterreinen tot schoolgebouwen. Veelal begonnen we met een ‘Moment’, een evenement opgezet door iedereen en voor iedereen. Regelmatig vonden we ook plekken voor een langere periode, en konden we er écht ons ding doen. Dan doopten we ze om tot ‘Spontane Actie Zones’ (SAZ).&nbsp;<br></p><p>Toestand verwezenlijkte sinds haar oprichting talloze tijdelijke projecten, met een duurtijd van enkele uren tot meerdere jaren. Vaak namen we initiatief, meestal werkten we samen met een breed netwerk aan sociaal-culturele organisaties.&nbsp;</p><p>We wierven in 2014 onze eerste personeelsleden aan op het project Allee Du Kaai en voor de inhoudelijke werking via een subsidie voor experimenteel jeugdwerk. Vandaag (2020) zijn we met 13 vaste (meestal halftijdse) medewerkers en tientallen vrijwilligers, verdeeld over meerdere projecten.&nbsp;</p>'
  -
    type: section
    section_title: Prijzen
    in_overview: true
    in_menu: false
    bard:
      -
        type: text
        text: '<p>Toestand werd in 2012 voor de Gouden Ketjes-prijs van de VGC genomineerd, voor haar werking en projecten binnen het beleidsdomein Cultuur, Jeugd en Sport. In 2017 werden we genomineerd voor de Mixity Awards van visit.brussels voor de diversiteit en inclusiviteit van het project Allee du Kaai, en in 2016 sleepten we de Vlaamse cultuurprijs Ultima in de wacht voor Sociaal-Cultureel Volwassenenwerk.&nbsp;</p>'
      -
        type: video
        value: 'https://youtu.be/qCPlJBSbmdw'
      -
        type: text
        text: '<p>Uit het juryrapport:<i>&nbsp;</i></p><p><i>”De acties van Toestand hebben een katalysatoreffect: ze brengen mensen in contact met socio- culturele initiatieven, ze laten mensen elkaar ontmoeten over scheidingslijnen heen, ze proberen een sociale dynamiek op gang te brengen in buurten die door de maatschappij zijn afgeschreven, ze betrekken de bevolking bij het creëren van nieuwe publieke ruimtes ... Toestand is een luis in de pels, die kraken naar voren schuift als positief alternatief, als startpunt voor vernieuwing van&nbsp;onderuit, voor verbetering ...”&nbsp;</i></p>'
title: 'Over Toestand'
date: '2019-04-22'
template: detail
hide_from_nav: false
history_show: true
history_title: Historiek
history_style: is-centered
id_on_page: historiek
show: true
fieldset: page__article
id: 913b22fc-c5de-4a73-afc6-676800c26eff
