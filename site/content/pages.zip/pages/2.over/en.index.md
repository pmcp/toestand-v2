intro: |
  <p>Vacant empty urban spaces have a huge transformative and creative potential, they mean so much more than decay and insecurity.
  </p>
  
title: 'About Toestand'
id: 913b22fc-c5de-4a73-afc6-676800c26eff
