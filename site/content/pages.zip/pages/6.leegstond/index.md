article-header__image:
  - /assets/toestand/38205921_1785925944788718_2829843085343588352_o-1555971158.jpg
intro: |
  <p>In haar bestaan heeft Toestand steeds ingezet op expertkennis, experiment en initiatief. Het ontwikkelen én delen van haar expertise liep via talloze lezingen, rondleidingen en presentaties. Toestand heeft veel ervaring met tijdelijk gebruik van leegstaande gebouwen en verlaten ruimtes. Op basis van de talrijke vragen die we hierover krijgen, besloten we onze  kennis en ervaringen te bundelen in een boek: "Leegstond - handleiding voor gebruik van leegstaande ruimte". <br>Leegstond bundelt zes jaar praktijkervaring, opgebouwd met tijdelijke projecten waaronder Allee du Kaai, BiestebroekBis en Marie Moskou en is anderzijds het resultaat van vier jaar intensief opzoekingswerk rond leegstand in heel België. In dit boek schetsen we de problematiek van leegstand, maar bovenal is Leegstond een praktische gids voor wie een leegstaand gebouw tijdelijk in gebruik wil nemen.
  </p>
  
article-sections:
  -
    type: section
    section_title: 'Waar te koop?'
    in_overview: true
    bard:
      -
        type: text
        text: '<p>Bij Toestand kost het boek 15€. U kan het verkrijgen aan de bar van Allee du Kaai, tijdens onze evenementen (tegen contante betaling).</p><p>Het boek is ook te koop in elf boekenwinkels in Brussel en Vlaanderen.</p><ul><li>Brussel:&nbsp;<a href="http://www.passaporta.be/home">Passa Porta</a>,&nbsp;<a href="https://www.facebook.com/crevetterecords/">Crevette Records</a>,&nbsp;<a href="http://www.wiels.org/en/">WIELS</a></li><li>Gent:&nbsp;<a href="https://www.copyrightbookshop.be/nl">Copyright Bookshop</a>&nbsp;(online ook te bestellen via hun <a href="https://www.copyrightbookshop.be/shop/leegstond-handleiding-voor-gebruik-van-leegstaande-ruimte/">webwinkel</a>)</li><li>Antwerpen:&nbsp;<a href="http://groenewaterman.mijnboekhandelaar.com/">De Groene Waterman</a>,&nbsp;<a href="https://www.copyrightbookshop.be/nl">Copyright&nbsp;</a></li><li>Kortrijk:&nbsp;<a href="http://www.budakortrijk.be/en">BUDA</a>&nbsp;</li><li>Oostende:&nbsp;<a href="https://www.facebook.com/pages/Boekhandel-Corman-Oostende/267512310098895">Boekhandel Corman</a>&nbsp;</li></ul>'
      -
        type: image
        value:
          - /assets/toestand/nb-leegstond.jpg
    in_menu: false
title: '"Leegstond": het boek'
date: '2019-04-22'
template: detail
hide_from_nav: false
fieldset: page__article
id: 9d059393-a711-41f6-91b5-816aa1a0bf78
