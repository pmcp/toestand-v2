intro: |
  <p>Au cours de son existence, Toestand a toujours mis l'accent sur l'expertise, l'expérience et l'initiative. Le développement et le partage de son expertise ont eu lieu au travers de nombreuses conférences, visites guidées et présentations. Toestand a une grande expérience avec l'usage temporaire des bâtiments vides et des espaces abandonnés.
  </p>
  <p>Sur la base des nombreuses questions que nous avons reçues à ce sujet, nous avons décidé de regrouper notre savoir-faire et nos expériences dans un livre (uniquement en néerlandais) : "Leegstond - handleiding voor gebruik van leegstaande ruimte".
  </p>
  <p>"Leegstond" regroupe six années d'expérience pratique, accumulées grâce à des projets temporaires comme Allee du Kaai, BiestebroekBis et Marie Moscou. D'autre part c'est le résultat de quatre années de recherche intensive sur les espaces vacants dans toute la Belgique. Ce livre se veut un guide pratique pour ceux qui veulent occuper temporairement un bâtiment vide.
  </p>
  
article-sections:
  -
    type: section
    section_title: 'Où acheter ?'
    in_overview: true
    bard:
      -
        type: text
        text: '<p>Chez Toestand, le livre coûte 15€. Vous pouvez l''obtenir au bar de l''Allee du Kaai, lors de nos événements (contre paiement en liquide).</p><p>&nbsp;Le livre est également en vente dans onze librairies à Bruxelles et en Flandre.</p><ul><li>Bruxelles:&nbsp;<a href="https://www.passaporta.be/fr/book-shop?locate=fr_be">Passa Porta</a>,&nbsp;<a href="https://www.crevetterecords.be">Crevette Records</a>,&nbsp;<a href="http://www.wiels.org/fr/bookshop/">WIELS</a></li><li>Gand:&nbsp;<a href="https://www.copyrightbookshop.be/en/">Copyright Bookshop</a>&nbsp;(online ook te bestellen via hun <a href="https://www.copyrightbookshop.be/shop/leegstond-handleiding-voor-gebruik-van-leegstaande-ruimte/">webwinkel</a>)</li><li>Anvers:&nbsp;<a href="http://groenewaterman.mijnboekhandelaar.com">De Groene Waterman</a>,&nbsp;<a href="https://www.copyrightbookshop.be/contact/">Copyright&nbsp;</a></li><li>Courtrai:&nbsp;<a href="http://www.budakortrijk.be/fr">BUDA</a>&nbsp;</li><li>Ostende:&nbsp;<a href="https://www.facebook.com/pages/Boekhandel-Corman-Oostende/267512310098895">Boekhandel Corman</a>&nbsp;</li></ul>'
      -
        type: image
        value:
          - /assets/toestand/nb-leegstond.jpg
    in_menu: false
title: 'Notre livre "Leegstond"'
id: 9d059393-a711-41f6-91b5-816aa1a0bf78
