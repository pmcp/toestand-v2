intro: |
  <ul>
  	<li>dfgdslkg: <a href="https://toestand.be/cp/assets/download/main/pdf/14-april-2018-keyelements-en.compressed.pdf">asdf</a></li>
  </ul><span></span>
article-sections:
  -
    type: section
    section_title: Bruzz
    in_overview: true
    in_menu: true
    bard:
      -
        type: text
        text: '<p>Iets over bruzz</p><p><br></p>'
  -
    type: section
    section_title: 'La Libre'
    in_overview: true
    in_menu: true
    bard:
      -
        type: text
        text: '<p>sadfadsf</p><p><br></p>'
title: 'In de pers'
date: '2020-06-10'
template: detail
hide_from_nav: false
fieldset: page__article
id: 49940b79-66c8-4548-bc41-cf6424900879
